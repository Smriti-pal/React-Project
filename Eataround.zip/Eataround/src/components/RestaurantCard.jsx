import React from "react";
import { Link } from "react-router-dom";

export default function RestaurantCard({ r }) {
  const avg = r.reviews?.length 
    ? (r.reviews.reduce((s, x) => s + x.rating, 0) / r.reviews.length).toFixed(1) 
    : "New";
  const reviewCount = r.reviews?.length || 0;

  return (
    <Link to={`/r/${r.id}`} style={{ textDecoration: "none" }}>
      <article className="card" style={{ position: "relative" }}>
        {r.bestseller && (
          <div style={{ position: "absolute", top: "8px", right: "8px", background: "#ffc107", color: "#333", padding: "6px 10px", borderRadius: "6px", fontSize: "0.8rem", fontWeight: "600", zIndex: 10 }}>
            ⭐ Bestseller
          </div>
        )}
        <img 
          src={r.images?.[0] || "https://images.unsplash.com/photo-1543353071-873f17a7a088?w=800&q=60"} 
          alt={r.name}
          loading="lazy"
        />
        <div className="body">
          <h3>{r.name}</h3>
          <p>{r.place || "Location not specified"}</p>
          {r.bestseller && (
            <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", marginTop: "6px" }}>
              🍽️ {r.bestseller.name}
            </p>
          )}
          <div className="card-footer">
            <span style={{ fontSize: "0.9rem" }}>
              ⭐ {avg} {reviewCount > 0 && `(${reviewCount})`}
            </span>
            <span style={{ color: "var(--accent)", fontWeight: "600", fontSize: "0.9rem" }}>→</span>
          </div>
        </div>
      </article>
    </Link>
  );
}
