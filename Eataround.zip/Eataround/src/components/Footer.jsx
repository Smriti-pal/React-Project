export default function Footer() {
  return (
    <footer>
      <div style={{ marginBottom: "12px", fontWeight: "600", color: "var(--text-primary)" }}>
        🍽️ EatAround
      </div>
      <p style={{ margin: "8px 0", fontSize: "0.85rem" }}>
        © {new Date().getFullYear()} EatAround — Discover local favorites
      </p>
      <p style={{ margin: "8px 0", fontSize: "0.85rem", opacity: "0.7" }}>
        Share your favorite restaurants and help your community find hidden gems
      </p>
    </footer>
  );
}
