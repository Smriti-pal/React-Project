import React from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Header({ user, onLogout }) {
  const nav = useNavigate();

  return (
    <header>
      <Link to="/" className="logo">
        <img src="/logo.svg" alt="EatAround logo" />
        <span>EatAround</span>
      </Link>

      <nav>
        <Link to="/">Home</Link>
        <Link to="/search">Explore</Link>
        <Link to="/suggest">Suggest</Link>
        <Link to="/nearby">Nearby</Link>
        {user && <Link to="/reservations">📅 Reservations</Link>}
        {user ? (
          <>
            <Link to="/profile" style={{ fontWeight: "600" }}>👤 {user.name}</Link>
            <button 
              className="btn btn-secondary" 
              onClick={() => { onLogout(); nav("/"); }}
            >
              Logout
            </button>
          </>
        ) : (
          <Link to="/login">
            <button className="btn btn-primary">Login</button>
          </Link>
        )}
      </nav>
    </header>
  );
}
