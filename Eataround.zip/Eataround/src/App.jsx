import React, { useEffect, useState } from "react";
import { Routes, Route, Navigate } from "react-router-dom";

import Header from "./components/Header";
import Home from "./routes/Home";
import Search from "./routes/Search";
import RestaurantPage from "./routes/RestaurantPage";
import Suggest from "./routes/Suggest";
import Login from "./routes/Login";
import Signup from "./routes/Signup";
import ForgotPassword from "./routes/ForgotPassword";
import Nearby from "./routes/Nearby";
import Profile from "./routes/Profile";
import Reservations from "./routes/Reservations";
import Footer from "./components/Footer";

export default function App(){
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem("ea_session") || "null"); } catch { return null; }
  });
  const [theme, setTheme] = useState(() => {
    return localStorage.getItem("ea_theme") || "light";
  });

  useEffect(()=> {
    if(user) localStorage.setItem("ea_session", JSON.stringify(user));
    else localStorage.removeItem("ea_session");
  }, [user]);

  useEffect(() => {
    localStorage.setItem("ea_theme", theme);
    if (theme === "dark") {
      document.documentElement.style.setProperty("--accent", "#ff6b9d");
      document.documentElement.style.setProperty("--accent-2", "#ff4d6d");
      document.documentElement.style.setProperty("--bg", "#0f0f0f");
      document.documentElement.style.setProperty("--text-primary", "#f0f0f0");
      document.documentElement.style.setProperty("--text-secondary", "#b0b0b0");
      document.documentElement.style.setProperty("--border", "#333333");
    } else {
      document.documentElement.style.setProperty("--accent", "#e63946");
      document.documentElement.style.setProperty("--accent-2", "#ff4d6d");
      document.documentElement.style.setProperty("--bg", "#f8fafb");
      document.documentElement.style.setProperty("--text-primary", "#111827");
      document.documentElement.style.setProperty("--text-secondary", "#6b7280");
      document.documentElement.style.setProperty("--border", "#e5e7eb");
    }
  }, [theme]);

  function handleLogout(){ setUser(null); }
  function handleLogin(u){ setUser(u); }
  function toggleTheme() { setTheme(theme === "light" ? "dark" : "light"); }

  return (
    <div className="min-h-screen" style={{display:"flex",flexDirection:"column"}}>
      <Header user={user} onLogout={handleLogout} />
      <main style={{flex:1}}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/search" element={<Search />} />
          <Route path="/r/:id" element={<RestaurantPage user={user} />} />
          <Route path="/suggest" element={<Suggest user={user} />} />
          <Route path="/nearby" element={<Nearby user={user} />} />
          <Route path="/profile" element={<Profile user={user} onLogout={handleLogout} theme={theme} toggleTheme={toggleTheme} />} />
          <Route path="/reservations" element={<Reservations user={user} />} />
          <Route path="/login" element={<Login onLogin={handleLogin} />} />
          <Route path="/signup" element={<Signup onLogin={handleLogin} />} />
          <Route path="/forgotpassword" element={<ForgotPassword />} />
          <Route path="*" element={<div className="container">Not found</div>} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}
