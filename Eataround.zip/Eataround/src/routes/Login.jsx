import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { login } from "../lib/storage";

export default function Login({ onLogin }) {
  const [email, setEmail] = useState("");
  const [pwd, setPwd] = useState("");
  const [err, setErr] = useState("");
  const nav = useNavigate();

  function submit(e) {
    e.preventDefault();
    const u = login(email.trim(), pwd.trim());
    if (!u) { 
      setErr("Invalid credentials. Demo: user@eataround / user123"); 
      return; 
    }
    onLogin({ id: u.id, name: u.name, email: u.email });
    nav("/");
  }

  return (
    <div className="container" style={{ maxWidth: "420px", margin: "60px auto" }}>
      <div className="card" style={{ padding: "32px" }}>
        <h1 style={{ color: "var(--accent)", marginBottom: "8px", fontSize: "1.8rem" }}>Welcome Back</h1>
        <p style={{ color: "var(--text-secondary)", marginBottom: "24px" }}>Sign in to your EatAround account</p>
        
        <form onSubmit={submit}>
          <div>
            <label htmlFor="email">Email</label>
            <input 
              id="email"
              type="email"
              placeholder="you@example.com" 
              value={email} 
              onChange={(e) => setEmail(e.target.value)}
              required 
            />
          </div>
          
          <div>
            <label htmlFor="password">Password</label>
            <input 
              id="password"
              type="password" 
              placeholder="Enter your password"
              value={pwd} 
              onChange={(e) => setPwd(e.target.value)}
              required 
            />
            <Link to="/forgotpassword" style={{ color: "var(--accent)", fontSize: "0.85rem", marginTop: "6px", display: "block", textAlign: "right", textDecoration: "none", fontWeight: "500" }}>Forgot Password?</Link>
          </div>
          
          {err && <div className="error">⚠️ {err}</div>}
          
          <button type="submit" className="btn btn-primary" style={{ marginTop: "12px" }}>Sign In</button>
        </form>
        
        <div style={{ marginTop: "20px", textAlign: "center", fontSize: "0.9rem" }}>
          Don't have an account? 
          <Link to="/signup" style={{ color: "var(--accent)", fontWeight: "600", marginLeft: "4px" }}>Create one</Link>
        </div>
        
        <div style={{ marginTop: "16px", padding: "12px", background: "var(--bg)", borderRadius: "8px", fontSize: "0.85rem", color: "var(--text-secondary)" }}>
          <strong>Demo Account:</strong><br />
          Email: user@eataround<br />
          Password: user123
        </div>
      </div>
    </div>
  );
}
