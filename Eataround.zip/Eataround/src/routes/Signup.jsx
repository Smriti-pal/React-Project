import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { register } from "../lib/storage";

export default function Signup({ onLogin }) {
  const [first, setFirst] = useState("");
  const [last, setLast] = useState("");
  const [email, setEmail] = useState("");
  const [pwd, setPwd] = useState("");
  const [state, setState] = useState("");
  const [location, setLocation] = useState("");
  const [err, setErr] = useState("");
  const nav = useNavigate();

  const states = [
    "Maharashtra",
    "Goa",
    "Karnataka",
    "Delhi",
    "West Bengal",
    "Tamil Nadu",
    "Rajasthan",
    "Kerala",
    "Punjab",
  ];

  function submit(e) {
    e.preventDefault();
    if (!first || !last || !email || !pwd || !state || !location) { 
      setErr("Please fill all fields"); 
      return; 
    }
    const u = register({ firstName: first, lastName: last, email, pwd, state, location });
    if (!u) { 
      setErr("User already exists"); 
      return; 
    }
    onLogin({ id: u.id, name: u.name, email: u.email });
    nav("/");
  }

  return (
    <div className="container" style={{ maxWidth: "480px", margin: "60px auto" }}>
      <div className="card" style={{ padding: "32px" }}>
        <h1 style={{ color: "var(--accent)", marginBottom: "8px", fontSize: "1.8rem" }}>Create Account</h1>
        <p style={{ color: "var(--text-secondary)", marginBottom: "24px" }}>Join EatAround and start sharing your favorite restaurants</p>
        
        <form onSubmit={submit}>
          <div style={{ display: "flex", gap: "12px" }}>
            <div style={{ flex: 1 }}>
              <label htmlFor="first">First Name</label>
              <input 
                id="first"
                type="text"
                placeholder="John" 
                value={first} 
                onChange={(e) => setFirst(e.target.value)}
                required 
              />
            </div>
            <div style={{ flex: 1 }}>
              <label htmlFor="last">Last Name</label>
              <input 
                id="last"
                type="text"
                placeholder="Doe" 
                value={last} 
                onChange={(e) => setLast(e.target.value)}
                required 
              />
            </div>
          </div>
          
          <div>
            <label htmlFor="signup-email">Email</label>
            <input 
              id="signup-email"
              type="email"
              placeholder="you@example.com" 
              value={email} 
              onChange={(e) => setEmail(e.target.value)}
              required 
            />
          </div>
          
          <div>
            <label htmlFor="signup-password">Password</label>
            <input 
              id="signup-password"
              type="password" 
              placeholder="Create a strong password"
              value={pwd} 
              onChange={(e) => setPwd(e.target.value)}
              required 
            />
          </div>

          <div>
            <label htmlFor="state">State</label>
            <select 
              id="state"
              value={state} 
              onChange={(e) => setState(e.target.value)}
              required 
              style={{ width: "100%", padding: "8px 12px", borderRadius: "6px", border: "1px solid var(--border)", background: "var(--card-bg)", color: "var(--text)", fontSize: "1rem", fontFamily: "inherit", cursor: "pointer" }}
            >
              <option value="">-- Select your state --</option>
              {states.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="location">City / Location</label>
            <input 
              id="location"
              type="text"
              placeholder="e.g., Mumbai, Bangalore, Delhi" 
              value={location} 
              onChange={(e) => setLocation(e.target.value)}
              required 
            />
          </div>
          
          {err && <div className="error">⚠️ {err}</div>}
          
          <button type="submit" className="btn btn-primary" style={{ marginTop: "12px" }}>Create Account</button>
        </form>
        
        <div style={{ marginTop: "20px", textAlign: "center", fontSize: "0.9rem" }}>
          Already have an account? 
          <Link to="/login" style={{ color: "var(--accent)", fontWeight: "600", marginLeft: "4px" }}>Sign in</Link>
        </div>
      </div>
    </div>
  );
}
