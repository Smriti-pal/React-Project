import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { getWishlist, getUserReviews, deleteReview, updateReview, getRestaurantById, updateUserProfile, deleteUserAccount } from "../lib/storage";
import RestaurantCard from "../components/RestaurantCard";

export default function Profile({ user, onLogout, theme, toggleTheme }) {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("reviews"); // reviews, wishlist, settings
  const [userReviews, setUserReviews] = useState(user ? getUserReviews(user.id) : []);
  const [wishlist, setWishlist] = useState(user ? getWishlist(user.id) : []);
  const [editingId, setEditingId] = useState(null);
  const [editingText, setEditingText] = useState("");
  const [editingRating, setEditingRating] = useState(5);
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editedName, setEditedName] = useState(user?.name || "");
  const [editedEmail, setEditedEmail] = useState(user?.email || "");
  const [editedPhone, setEditedPhone] = useState(user?.phone || "");
  const [profilePicture, setProfilePicture] = useState(user?.profilePicture || "");

  if (!user) {
    return (
      <div className="container" style={{ textAlign: "center", padding: "60px 20px" }}>
        <h2 style={{ marginBottom: "16px" }}>Please log in to view your profile</h2>
        <Link to="/login" className="btn btn-primary">Sign In</Link>
      </div>
    );
  }

  function handleDeleteReview(restaurantId, reviewId) {
    const ok = confirm("Delete this review?");
    if (!ok) return;
    const res = deleteReview(restaurantId, reviewId, user.id);
    if (!res) { alert("Unable to delete review"); return; }
    setUserReviews(userReviews.filter(r => r.id !== reviewId));
  }

  function startEdit(review) {
    setEditingId(review.id);
    setEditingText(review.text || "");
    setEditingRating(review.rating || 5);
  }

  function cancelEdit() {
    setEditingId(null);
    setEditingText("");
    setEditingRating(5);
  }

  function saveEdit(review) {
    const updated = updateReview(review.restaurantId, review.id, { rating: Number(editingRating), text: editingText }, user.id);
    if (!updated) { alert("Unable to update review"); return; }
    setUserReviews(userReviews.map(r => r.id === review.id ? { ...r, rating: Number(editingRating), text: editingText, editedAt: Date.now() } : r));
    cancelEdit();
  }

  function handleProfilePictureChange(e) {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfilePicture(reader.result);
      };
      reader.readAsDataURL(file);
    }
  }

  function saveProfileChanges() {
    if (!editedName.trim()) { alert("Name cannot be empty"); return; }
    if (!editedEmail.trim()) { alert("Email cannot be empty"); return; }
    const updated = updateUserProfile(user.id, {
      name: editedName,
      email: editedEmail,
      phone: editedPhone,
      profilePicture: profilePicture
    });
    if (updated) {
      alert("Profile updated successfully!");
      // Update user in localStorage
      localStorage.setItem("ea_session", JSON.stringify(updated));
      setIsEditingProfile(false);
      window.location.reload();
    }
  }

  function handleDeleteAccount() {
    const confirmed = window.confirm("⚠️ Are you absolutely sure? This will permanently delete your account, all reviews, and reservations. This action cannot be undone.");
    if (!confirmed) return;
    const doubleConfirm = window.prompt("Type your email to confirm deletion:", "");
    if (doubleConfirm !== user.email) { alert("Email does not match. Account deletion cancelled."); return; }
    
    const deleted = deleteUserAccount(user.id);
    if (deleted) {
      alert("Your account has been deleted. Redirecting...");
      onLogout();
      navigate("/");
    }
  }

  return (
    <div className="container">
      {/* Profile Header with Theme Toggle */}
      <div style={{ marginBottom: "32px", display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "20px", flexWrap: "wrap" }}>
        <div>
          {profilePicture ? (
            <img src={profilePicture} alt={user.name} style={{ width: "100px", height: "100px", borderRadius: "50%", objectFit: "cover", marginBottom: "16px", border: "3px solid var(--accent)" }} />
          ) : (
            <div style={{ width: "100px", height: "100px", borderRadius: "50%", background: "var(--accent)", color: "white", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "3rem", marginBottom: "16px" }}>
              👤
            </div>
          )}
          <h1 style={{ marginBottom: "4px", fontSize: "2.2rem" }}>{user.name}</h1>
          <p style={{ color: "var(--text-secondary)", marginBottom: "8px" }}>{user.email}</p>
          {user.phone && <p style={{ color: "var(--text-secondary)", marginBottom: "8px" }}>📱 {user.phone}</p>}
        </div>
        <div style={{ display: "flex", gap: "8px", flexDirection: "column" }}>
          <button 
            onClick={toggleTheme}
            style={{
              padding: "10px 16px",
              background: "var(--accent)",
              color: "white",
              border: "none",
              borderRadius: "8px",
              cursor: "pointer",
              fontWeight: "600",
              fontSize: "0.95rem"
            }}
          >
            {theme === "light" ? "🌙 Dark Mode" : "☀️ Light Mode"}
          </button>
          <button 
            onClick={() => setIsEditingProfile(!isEditingProfile)}
            style={{
              padding: "10px 16px",
              background: "var(--accent)",
              color: "white",
              border: "none",
              borderRadius: "8px",
              cursor: "pointer",
              fontWeight: "600",
              fontSize: "0.95rem"
            }}
          >
            ✏️ {isEditingProfile ? "Cancel" : "Edit Profile"}
          </button>
        </div>
      </div>

      {/* Edit Profile Section */}
      {isEditingProfile && (
        <div style={{ background: "white", padding: "24px", borderRadius: "12px", marginBottom: "32px", border: "2px solid var(--accent)" }}>
          <h2 style={{ marginBottom: "20px", fontSize: "1.5rem" }}>Edit Your Profile</h2>
          
          <div style={{ marginBottom: "16px" }}>
            <label style={{ fontWeight: "600", display: "block", marginBottom: "8px" }}>Profile Picture</label>
            <input 
              type="file" 
              accept="image/*"
              onChange={handleProfilePictureChange}
              style={{ padding: "8px", borderRadius: "6px", border: "1px solid var(--border)", width: "100%", cursor: "pointer" }}
            />
            <small style={{ color: "var(--text-secondary)", display: "block", marginTop: "4px" }}>Upload a JPG or PNG image</small>
          </div>

          <div style={{ marginBottom: "16px" }}>
            <label style={{ fontWeight: "600", display: "block", marginBottom: "8px" }}>Full Name</label>
            <input 
              type="text"
              value={editedName}
              onChange={(e) => setEditedName(e.target.value)}
              style={{ padding: "10px", borderRadius: "6px", border: "1px solid var(--border)", width: "100%", fontFamily: "inherit", fontSize: "1rem" }}
            />
          </div>

          <div style={{ marginBottom: "16px" }}>
            <label style={{ fontWeight: "600", display: "block", marginBottom: "8px" }}>Email Address</label>
            <input 
              type="email"
              value={editedEmail}
              onChange={(e) => setEditedEmail(e.target.value)}
              style={{ padding: "10px", borderRadius: "6px", border: "1px solid var(--border)", width: "100%", fontFamily: "inherit", fontSize: "1rem" }}
            />
          </div>

          <div style={{ marginBottom: "16px" }}>
            <label style={{ fontWeight: "600", display: "block", marginBottom: "8px" }}>Phone Number (Optional)</label>
            <input 
              type="tel"
              value={editedPhone}
              onChange={(e) => setEditedPhone(e.target.value)}
              style={{ padding: "10px", borderRadius: "6px", border: "1px solid var(--border)", width: "100%", fontFamily: "inherit", fontSize: "1rem" }}
            />
          </div>

          <div style={{ display: "flex", gap: "8px" }}>
            <button className="btn btn-primary" onClick={saveProfileChanges} style={{ flex: 1 }}>💾 Save Changes</button>
            <button className="btn" onClick={() => setIsEditingProfile(false)} style={{ flex: 1, background: "var(--border)", color: "var(--text-primary)" }}>Cancel</button>
          </div>

          <hr style={{ margin: "24px 0", border: "1px solid var(--border)" }} />

          <div style={{ padding: "16px", background: "rgba(239, 68, 68, 0.1)", borderRadius: "8px", borderLeft: "4px solid var(--error)" }}>
            <h3 style={{ marginBottom: "12px", color: "var(--error)", fontSize: "1.1rem" }}>⚠️ Delete Account</h3>
            <p style={{ color: "var(--text-secondary)", marginBottom: "12px", lineHeight: "1.6" }}>
              Deleting your account will permanently remove all your reviews, reservations, and profile data. This action cannot be undone.
            </p>
            <button 
              onClick={handleDeleteAccount}
              style={{
                padding: "10px 20px",
                background: "var(--error)",
                color: "white",
                border: "none",
                borderRadius: "6px",
                cursor: "pointer",
                fontWeight: "600"
              }}
            >
              🗑️ Delete My Account
            </button>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div style={{ display: "flex", gap: "12px", marginBottom: "32px", borderBottom: "2px solid var(--border)", flexWrap: "wrap" }}>
        <button 
          onClick={() => setActiveTab("reviews")}
          style={{
            padding: "12px 20px",
            background: activeTab === "reviews" ? "var(--accent)" : "transparent",
            color: activeTab === "reviews" ? "white" : "var(--text-primary)",
            border: "none",
            borderBottom: activeTab === "reviews" ? "3px solid var(--accent)" : "none",
            cursor: "pointer",
            fontWeight: "600",
            fontSize: "1rem"
          }}
        >
          ⭐ My Reviews ({userReviews.length})
        </button>
        <button 
          onClick={() => setActiveTab("wishlist")}
          style={{
            padding: "12px 20px",
            background: activeTab === "wishlist" ? "var(--accent)" : "transparent",
            color: activeTab === "wishlist" ? "white" : "var(--text-primary)",
            border: "none",
            borderBottom: activeTab === "wishlist" ? "3px solid var(--accent)" : "none",
            cursor: "pointer",
            fontWeight: "600",
            fontSize: "1rem"
          }}
        >
          ❤️ Wishlist ({wishlist.length})
        </button>
      </div>

      {activeTab === "reviews" && (
        <div>
          {userReviews.length > 0 ? (
            <div style={{ display: "grid", gap: "20px" }}>
              {userReviews.map(review => (
                <div key={review.id} style={{ background: "white", padding: "24px", borderRadius: "12px", borderLeft: "4px solid var(--accent)" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start", marginBottom: "12px" }}>
                    <div>
                      <Link to={`/r/${review.restaurantId}`} style={{ textDecoration: "none", color: "var(--accent)", fontWeight: "600", fontSize: "1.1rem" }}>
                        {review.restaurantName}
                      </Link>
                      <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem", margin: "4px 0" }}>📍 {review.restaurantPlace}</p>
                    </div>
                    <span style={{ fontSize: "1rem" }}>{"⭐".repeat(review.rating)}</span>
                  </div>

                  {editingId === review.id ? (
                    <div>
                      <div style={{ marginBottom: "12px" }}>
                        <label style={{ fontWeight: "600", display: "block", marginBottom: "6px" }}>Rating</label>
                        <select value={editingRating} onChange={e => setEditingRating(e.target.value)} style={{ width: "100%" }}>
                          {[5,4,3,2,1].map(n => <option key={n} value={n}>{n} star{n!==1? 's':''}</option>)}
                        </select>
                      </div>
                      <div style={{ marginBottom: "12px" }}>
                        <label style={{ fontWeight: "600", display: "block", marginBottom: "6px" }}>Edit Your Review</label>
                        <textarea value={editingText} onChange={e => setEditingText(e.target.value)} rows={3} style={{ width: "100%", padding: "8px", borderRadius: "6px", border: "1px solid var(--border)" }} />
                      </div>
                      <div style={{ display: "flex", gap: "8px" }}>
                        <button className="btn btn-primary" onClick={() => saveEdit(review)}>Save Changes</button>
                        <button className="btn" onClick={cancelEdit} style={{ background: "var(--border)", color: "var(--text-primary)" }}>Cancel</button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <p style={{ margin: "12px 0", color: "var(--text-primary)", lineHeight: "1.6" }}>{review.text || "No comment provided"}</p>
                      <div style={{ display: "flex", gap: "8px", marginTop: "16px" }}>
                        <button className="btn" onClick={() => startEdit(review)} style={{ background: "white", color: "var(--accent)", border: "2px solid var(--accent)" }}>
                          ✏️ Edit
                        </button>
                        <button className="btn" onClick={() => handleDeleteReview(review.restaurantId, review.id)} style={{ background: "white", color: "var(--error)", border: "2px solid var(--error)" }}>
                          🗑️ Delete
                        </button>
                      </div>
                      <small style={{ color: "var(--text-secondary)", fontSize: "0.85rem", display: "block", marginTop: "8px" }}>
                        Posted on {new Date(review.createdAt).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" })}
                        {review.editedAt && ` (Edited)`}
                      </small>
                    </>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div style={{ textAlign: "center", padding: "40px 20px", background: "white", borderRadius: "12px" }}>
              <p style={{ color: "var(--text-secondary)", marginBottom: "12px" }}>You haven't reviewed any restaurants yet.</p>
              <Link to="/search" className="btn btn-primary">Find a Restaurant</Link>
            </div>
          )}
        </div>
      )}

      {activeTab === "wishlist" && (
        <div>
          {wishlist.length > 0 ? (
            <div className="grid">
              {wishlist.map(r => <RestaurantCard key={r.id} r={r} />)}
            </div>
          ) : (
            <div style={{ textAlign: "center", padding: "40px 20px", background: "white", borderRadius: "12px" }}>
              <p style={{ color: "var(--text-secondary)", marginBottom: "12px" }}>Your wishlist is empty.</p>
              <Link to="/search" className="btn btn-primary">Explore Restaurants</Link>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
