import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import RestaurantCard from "../components/RestaurantCard";
import { getRestaurants } from "../lib/storage";

// Haversine formula to calculate distance between two coordinates (in km)
function calculateDistance(lat1, lng1, lat2, lng2) {
  const R = 6371; // Earth's radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

export default function Nearby({ user }) {
  const [nearby, setNearby] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [userLocation, setUserLocation] = useState(null);

  useEffect(() => {
    if (!navigator.geolocation) {
      setError("Geolocation is not supported by your browser");
      setLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const userLat = position.coords.latitude;
        const userLng = position.coords.longitude;
        setUserLocation({ lat: userLat, lng: userLng });
        const restaurants = getRestaurants();
        
        // Calculate actual distance using Haversine formula and filter within 10km
        const nearbyRestaurants = restaurants
          .map(r => ({
            ...r,
            distance: r.lat && r.lng ? calculateDistance(userLat, userLng, r.lat, r.lng) : Infinity
          }))
          .filter(r => r.distance <= 10) // Within 10km only
          .sort((a, b) => a.distance - b.distance);
        
        setNearby(nearbyRestaurants);
        setLoading(false);
      },
      (err) => {
        setError("Unable to retrieve your location. Please enable location access.");
        setLoading(false);
      }
    );
  }, []);

  return (
    <div className="container">
      <h2 style={{ marginBottom: "12px" }}>📍 Nearby Restaurants</h2>
      <p style={{ color: "var(--text-secondary)", marginBottom: "24px" }}>Discover delicious restaurants near your location</p>
      
      {loading && (
        <div className="loading" style={{ minHeight: "200px" }} />
      )}
      
      {error && (
        <div className="error">
          ⚠️ {error}
        </div>
      )}
      
      {!loading && !error && (
        <>
          {userLocation && (
            <div style={{ marginBottom: "20px", padding: "12px", background: "#e8f5e9", borderRadius: "8px", color: "#2e7d32", fontSize: "0.9rem" }}>
              📍 Your location: <strong>{userLocation.lat.toFixed(4)}, {userLocation.lng.toFixed(4)}</strong>
            </div>
          )}
          {nearby.length > 0 ? (
            <>
              <div style={{ marginBottom: "20px", color: "var(--text-secondary)", fontSize: "0.95rem" }}>
                Found <strong>{nearby.length}</strong> restaurant{nearby.length !== 1 ? "s" : ""} within <strong>10 km</strong> of your location
              </div>
              <div className="grid">
                {nearby.map(r => (
                  <div key={r.id}>
                    <RestaurantCard r={r} />
                    <div style={{ textAlign: "center", color: "var(--text-secondary)", fontSize: "0.85rem", marginTop: "8px" }}>
                      📏 {r.distance.toFixed(2)} km away
                    </div>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div style={{ textAlign: "center", padding: "60px 20px", background: "white", borderRadius: "12px" }}>
              <p style={{ color: "var(--text-secondary)", marginBottom: "12px" }}>No restaurants found within 10km of your location.</p>
              <p style={{ fontSize: "0.9rem", color: "var(--text-secondary)", marginBottom: "16px" }}>Try exploring other areas or <Link to="/search" style={{ color: "var(--accent)", fontWeight: "600" }}>search for restaurants</Link></p>
            </div>
          )}
        </>
      )}
    </div>
  );
}
