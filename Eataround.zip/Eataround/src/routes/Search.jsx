import React, { useState, useEffect } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { searchRestaurants } from "../lib/storage";
import RestaurantCard from "../components/RestaurantCard";

export default function Search() {
  const [searchParams] = useSearchParams();
  const [q, setQ] = useState("");
  const [results, setResults] = useState([]);
  const [searched, setSearched] = useState(false);

  // Check URL for query parameter on mount
  useEffect(() => {
    const queryParam = searchParams.get("q");
    if (queryParam) {
      setQ(queryParam);
      performSearch(queryParam);
    }
  }, [searchParams]);

  const performSearch = (searchQuery) => {
    if (searchQuery.trim()) {
      const found = searchRestaurants(searchQuery);
      setResults(found);
      setSearched(true);
    }
  };

  const doSearch = (e) => {
    e?.preventDefault();
    if (q.trim()) {
      performSearch(q);
    }
  };

  return (
    <div className="container">
      <h2 style={{ marginBottom: "24px" }}>🔍 Search Restaurants</h2>
      
      <form onSubmit={doSearch} style={{ display: "flex", gap: "12px", marginBottom: "32px" }}>
        <input 
          type="text"
          value={q} 
          onChange={(e) => setQ(e.target.value)} 
          placeholder="Search by restaurant name or location..."
          style={{ flex: 1 }}
        />
        <button type="submit" className="btn btn-primary">Search</button>
      </form>

      {searched && (
        <div style={{ marginBottom: "20px", color: "var(--text-secondary)" }}>
          Found {results.length} result{results.length !== 1 ? "s" : ""} for "{q}"
        </div>
      )}

      {results.length > 0 ? (
        <div className="grid">
          {results.map(r => <RestaurantCard key={r.id} r={r} />)}
        </div>
      ) : (
        searched && (
          <div style={{ textAlign: "center", padding: "40px 20px", color: "var(--text-secondary)" }}>
            <p>No restaurants found matching "{q}"</p>
            <p style={{ fontSize: "0.9rem", marginTop: "8px" }}>
              Try searching with different keywords or <Link to="/suggest" style={{ color: "var(--accent)", fontWeight: "600" }}>suggest a new restaurant</Link>
            </p>
          </div>
        )
      )}
    </div>
  );
}
