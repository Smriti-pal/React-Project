import React, { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { getRestaurantById, addReview, deleteReview, updateReview, isInWishlist, addToWishlist, removeFromWishlist, makeReservation } from "../lib/storage";

export default function RestaurantPage({ user }) {
  const { id } = useParams();
  const initial = getRestaurantById(id);
  const [restaurant, setRestaurant] = useState(initial);
  const [rating, setRating] = useState(5);
  const [text, setText] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [editingText, setEditingText] = useState("");
  const [editingRating, setEditingRating] = useState(5);
  const [showReservation, setShowReservation] = useState(false);
  const [resDate, setResDate] = useState("");
  const [resTime, setResTime] = useState("19:00");
  const [resGuests, setResGuests] = useState("2");
  const [resName, setResName] = useState(user?.name || "");
  const [resPhone, setResPhone] = useState("");
  const [isWishlisted, setIsWishlisted] = useState(user ? isInWishlist(user.id, id) : false);

  if (!restaurant) return <div className="container">🍽️ Restaurant not found</div>;

  function submit(e){
    e.preventDefault();
    if(!user){ alert("Please login to add a review"); return; }
    addReview(id, { userId: user.id, userName: user.name, rating: Number(rating), text });
    setRestaurant(getRestaurantById(id));
    setRating(5);
    setText("");
  }

  function handleDelete(reviewId){
    if(!user) { alert("You must be logged in to delete your review"); return; }
    const ok = confirm("Delete this review? This cannot be undone.");
    if(!ok) return;
    const res = deleteReview(id, reviewId, user.id);
    if(!res) { alert("Unable to delete review"); return; }
    setRestaurant(getRestaurantById(id));
  }

  function startEdit(rv){
    setEditingId(rv.id);
    setEditingText(rv.text || "");
    setEditingRating(rv.rating || 5);
  }

  function toggleWishlist(){
    if(!user) { alert("Please login to add to wishlist"); return; }
    if(isWishlisted){
      removeFromWishlist(user.id, id);
      setIsWishlisted(false);
    } else {
      addToWishlist(user.id, id);
      setIsWishlisted(true);
    }
  }

  function submitReservation(e){
    e.preventDefault();
    if(!user) { alert("Please login to make a reservation"); return; }
    if(!resDate) { alert("Please select a date"); return; }
    if(!resPhone) { alert("Please enter your phone number"); return; }
    
    // Save reservation to storage
    const reservation = makeReservation(user.id, id, {
      date: resDate,
      time: resTime,
      guests: resGuests,
      name: resName || user.name,
      phone: resPhone
    });
    
    if(reservation) {
      alert(`Reservation confirmed!\n📍 ${restaurant.name}\n📅 ${resDate} at ${resTime}\n👥 ${resGuests} guests\nConfirmation sent to ${resPhone}\n\nView your reservations in the Reservations page!`);
      setShowReservation(false);
      setResDate("");
      setResTime("19:00");
      setResGuests("2");
      setResPhone("");
    } else {
      alert("Error creating reservation. Please try again.");
    }
  }

  function cancelEdit(){
    setEditingId(null);
    setEditingText("");
    setEditingRating(5);
  }

  function saveEdit(reviewId){
    if(!user) { alert("You must be logged in to edit your review"); return; }
    const updated = updateReview(id, reviewId, { rating: Number(editingRating), text: editingText }, user.id);
    if(!updated) { alert("Unable to update review"); return; }
    setRestaurant(getRestaurantById(id));
    cancelEdit();
  }

  const avgRating = restaurant.reviews?.length 
    ? (restaurant.reviews.reduce((s, x) => s + x.rating, 0) / restaurant.reviews.length).toFixed(1)
    : null;

  return (
    <div className="container">
      <div style={{ display: "flex", gap: "32px", alignItems: "flex-start", marginBottom: "40px" }}>
        <div style={{ flex: 1 }}>
          <h1 style={{ marginBottom: "8px", fontSize: "2rem" }}>{restaurant.name}</h1>
          <p style={{ color: "var(--text-secondary)", marginBottom: "4px", fontSize: "1.1rem" }}>📍 {restaurant.place}</p>
          {avgRating && (
            <p style={{ marginBottom: "16px" }}>
              <span style={{ fontSize: "1.1rem" }}>
                ⭐ {avgRating}
              </span>
              <span style={{ color: "var(--text-secondary)", marginLeft: "8px" }}>
                ({restaurant.reviews.length} review{restaurant.reviews.length !== 1 ? "s" : ""})
              </span>
            </p>
          )}
          <p style={{ marginTop: "20px", lineHeight: "1.8", color: "var(--text-primary)" }}>{restaurant.desc || "No description provided"}</p>
          
          {restaurant.bestseller && (
            <div style={{ marginTop: "24px", padding: "16px", background: "#fff3cd", borderRadius: "12px", borderLeft: "4px solid #ffc107" }}>
              <h3 style={{ marginBottom: "8px", color: "#856404" }}>⭐ Bestseller</h3>
              <div style={{ display: "flex", gap: "16px", alignItems: "center" }}>
                <img src={restaurant.bestseller.image} alt={restaurant.bestseller.name} style={{ width: "100px", height: "100px", borderRadius: "8px", objectFit: "cover" }} />
                <div>
                  <h4 style={{ marginBottom: "4px", color: "#333" }}>{restaurant.bestseller.name}</h4>
                  <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>Most loved dish by our customers</p>
                </div>
              </div>
            </div>
          )}

          {restaurant.menu && restaurant.menu.length > 0 && (
            <div style={{ marginTop: "32px", padding: "24px", background: "#f8f9fa", borderRadius: "12px" }}>
              <h2 style={{ marginBottom: "20px", fontSize: "1.5rem" }}>📋 Full Menu</h2>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px" }}>
                {restaurant.menu.map((item) => (
                  <div 
                    key={item.id} 
                    style={{
                      background: "white",
                      padding: "16px",
                      borderRadius: "12px",
                      border: "1px solid var(--border)",
                      transition: "transform 0.2s, box-shadow 0.2s",
                      cursor: "pointer",
                      ":hover": {
                        transform: "translateY(-2px)",
                        boxShadow: "0 4px 12px rgba(15,23,42,0.12)"
                      }
                    }}
                  >
                    {item.image && (
                      <img 
                        src={item.image} 
                        alt={item.name} 
                        style={{ 
                          width: "100%", 
                          height: "180px", 
                          objectFit: "cover", 
                          borderRadius: "8px", 
                          marginBottom: "12px" 
                        }} 
                      />
                    )}
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start", marginBottom: "8px" }}>
                      <h4 style={{ margin: "0", flex: 1 }}>{item.name}</h4>
                      <span style={{ color: "var(--accent)", fontWeight: "700", whiteSpace: "nowrap", marginLeft: "8px" }}>₹{item.price}</span>
                    </div>
                    <div style={{ display: "flex", gap: "8px", flexWrap: "wrap", marginTop: "8px" }}>
                      <span style={{ 
                        fontSize: "0.75rem", 
                        background: "var(--accent)", 
                        color: "white", 
                        padding: "4px 8px", 
                        borderRadius: "4px",
                        fontWeight: "500"
                      }}>
                        {item.category}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        
        <div style={{ width: "320px", position: "sticky", top: "100px" }}>
          <div style={{ background: "white", padding: "24px", borderRadius: "16px", boxShadow: "0 2px 12px rgba(15,23,42,0.08)", marginBottom: "16px" }}>
            <div style={{ display: "flex", gap: "8px", marginBottom: "16px" }}>
              <button 
                onClick={toggleWishlist}
                className="btn" 
                style={{ flex: 1, background: isWishlisted ? "var(--accent)" : "white", color: isWishlisted ? "white" : "var(--accent)", border: isWishlisted ? "none" : "2px solid var(--accent)" }}
              >
                {isWishlisted ? "❤️ Wishlisted" : "🤍 Add to Wishlist"}
              </button>
              {restaurant.reservations && (
                <button 
                  onClick={() => setShowReservation(!showReservation)}
                  className="btn btn-primary"
                  style={{ flex: 1 }}
                >
                  {showReservation ? "✕" : "🗓️"}
                </button>
              )}
            </div>

            {showReservation && restaurant.reservations && (
              <form onSubmit={submitReservation} style={{ marginBottom: "16px", paddingTop: "16px", borderTop: "1px solid var(--border)" }}>
                <h4 style={{ marginBottom: "12px" }}>Make a Reservation</h4>
                <div>
                  <label htmlFor="res-date">Date *</label>
                  <input 
                    id="res-date"
                    type="date"
                    value={resDate} 
                    onChange={(e) => setResDate(e.target.value)}
                    required
                  />
                </div>
                <div style={{ marginTop: "8px" }}>
                  <label htmlFor="res-time">Time</label>
                  <input 
                    id="res-time"
                    type="time"
                    value={resTime} 
                    onChange={(e) => setResTime(e.target.value)}
                  />
                </div>
                <div style={{ marginTop: "8px" }}>
                  <label htmlFor="res-guests">Guests</label>
                  <select value={resGuests} onChange={(e) => setResGuests(e.target.value)}>
                    {[1,2,3,4,5,6,8,10].map(n => <option key={n} value={n}>{n} guest{n !== 1 ? "s" : ""}</option>)}
                  </select>
                </div>
                <div style={{ marginTop: "8px" }}>
                  <label htmlFor="res-name">Name</label>
                  <input 
                    id="res-name"
                    type="text"
                    value={resName} 
                    onChange={(e) => setResName(e.target.value)}
                    required
                  />
                </div>
                <div style={{ marginTop: "8px" }}>
                  <label htmlFor="res-phone">Phone</label>
                  <input 
                    id="res-phone"
                    type="tel"
                    value={resPhone} 
                    onChange={(e) => setResPhone(e.target.value)}
                    required
                  />
                </div>
                <button type="submit" className="btn btn-primary" style={{ marginTop: "12px", width: "100%" }}>
                  Confirm Reservation
                </button>
              </form>
            )}

            <h3 style={{ marginBottom: "16px" }}>Leave a Review</h3>
            {!user && (
              <div className="error" style={{ marginBottom: "12px" }}>
                Please <Link to="/login" style={{ color: "var(--accent)", fontWeight: "600" }}>sign in</Link> to write a review
              </div>
            )}
            <form onSubmit={submit}>
              <div>
                <label htmlFor="rating">Rating</label>
                <select 
                  id="rating"
                  value={rating} 
                  onChange={(e)=>setRating(e.target.value)}
                  disabled={!user}
                >
                  {[5,4,3,2,1].map(n=> <option key={n} value={n}>{"⭐".repeat(n)} {n} star{n !== 1 ? "s" : ""}</option>)}
                </select>
              </div>
              
              <div>
                <label htmlFor="comment">Your Review</label>
                <textarea 
                  id="comment"
                  value={text} 
                  onChange={(e)=>setText(e.target.value)} 
                  placeholder="Share your experience..."
                  rows="4"
                  disabled={!user}
                />
              </div>
              
              <button type="submit" className="btn btn-primary" disabled={!user}>
                Submit Review
              </button>
            </form>
          </div>
        </div>
      </div>

      <div>
        <h2 style={{ marginBottom: "20px" }}>Reviews ({restaurant.reviews?.length || 0})</h2>
        {restaurant.reviews && restaurant.reviews.length ? (
          <div style={{ display: "grid", gap: "16px" }}>
            {restaurant.reviews.slice().reverse().map(rv => (
              <div key={rv.id} style={{ background: "white", padding: "20px", borderRadius: "12px", borderLeft: "4px solid var(--accent)" }}>
                {editingId === rv.id ? (
                  <div>
                    <div style={{ marginBottom: 8 }}>
                      <label style={{ fontWeight: 600 }}>Rating</label>
                      <select value={editingRating} onChange={e => setEditingRating(e.target.value)}>
                        {[5,4,3,2,1].map(n => <option key={n} value={n}>{n} star{n!==1? 's':''}</option>)}
                      </select>
                    </div>
                    <div>
                      <label style={{ fontWeight: 600 }}>Edit Review</label>
                      <textarea value={editingText} onChange={e => setEditingText(e.target.value)} rows={3} style={{ width: '100%' }} />
                    </div>
                    <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
                      <button className="btn btn-primary" onClick={() => saveEdit(rv.id)}>Save</button>
                      <button className="btn" onClick={cancelEdit}>Cancel</button>
                    </div>
                  </div>
                ) : (
                <>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px" }}>
                    <strong style={{ fontSize: "1rem" }}>👤 {rv.userName || "Anonymous User"}</strong>
                    <span style={{ fontSize: "1.1rem" }}>{"⭐".repeat(rv.rating)}</span>
                  </div>
                  <p style={{ margin: "8px 0", color: "var(--text-primary)", lineHeight: "1.6" }}>{rv.text || "No comment provided"}</p>
                  <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                    {user && rv.userId === user.id && (
                      <>
                        <button className="btn" onClick={() => startEdit(rv)}>Edit</button>
                        <button className="btn" onClick={() => handleDelete(rv.id)}>Delete</button>
                      </>
                    )}
                  </div>
                  <small style={{ color: "var(--text-secondary)", fontSize: "0.85rem" }}>
                    {new Date(rv.createdAt).toLocaleDateString("en-US", { 
                      year: "numeric", 
                      month: "short", 
                      day: "numeric",
                      hour: "2-digit",
                      minute: "2-digit"
                    })}
                  </small>
                </>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div style={{ textAlign: "center", padding: "40px 20px", background: "white", borderRadius: "12px" }}>
            <p style={{ color: "var(--text-secondary)" }}>No reviews yet. Be the first to share your experience!</p>
          </div>
        )}
      </div>
    </div>
  );
}
