import React, { useState } from "react";
import { addSuggestion } from "../lib/storage";

export default function Suggest({ user }) {
  const [name, setName] = useState("");
  const [place, setPlace] = useState("");
  const [desc, setDesc] = useState("");
  const [msg, setMsg] = useState("");

  async function tryGeo() {
    if (!navigator.geolocation) return null;
    return new Promise((res, rej) => navigator.geolocation.getCurrentPosition(p => res(p.coords), rej));
  }

  async function submit(e) {
    e.preventDefault();
    const coords = await tryGeo().catch(() => null);
    addSuggestion({ name, place, desc, lat: coords?.latitude, lng: coords?.longitude, suggestedBy: user?.id || "anon" });
    setMsg("Thanks! Your suggestion was submitted for review.");
    setName(""); setPlace(""); setDesc("");
  }

  return (
    <div className="container" style={{ maxWidth: "680px" }}>
      <h2 style={{ marginBottom: "12px" }}>🍽️ Suggest a Restaurant</h2>
      <p style={{ color: "var(--text-secondary)", marginBottom: "24px" }}>Know a great place to eat? Help others discover your favorite hidden gems!</p>
      
      <form onSubmit={submit} style={{ background: "white", padding: "24px", borderRadius: "16px", boxShadow: "0 2px 12px rgba(15,23,42,0.08)" }}>
        <div>
          <label htmlFor="name">Restaurant Name *</label>
          <input 
            id="name"
            type="text"
            required 
            value={name} 
            onChange={(e) => setName(e.target.value)} 
            placeholder="e.g., The Local Kitchen"
          />
        </div>
        
        <div>
          <label htmlFor="place">City or Location *</label>
          <input 
            id="place"
            type="text"
            required 
            value={place} 
            onChange={(e) => setPlace(e.target.value)} 
            placeholder="e.g., Mumbai, India"
          />
        </div>
        
        <div>
          <label htmlFor="desc">Description</label>
          <textarea 
            id="desc"
            value={desc} 
            onChange={(e) => setDesc(e.target.value)} 
            placeholder="Tell us what makes this place special..." 
            rows="5"
          />
        </div>
        
        <div style={{ display: "flex", gap: "12px", flexWrap: "wrap" }}>
          <button type="submit" className="btn btn-primary">✓ Submit Suggestion</button>
          <button 
            type="button" 
            className="btn btn-secondary" 
            onClick={async () => { 
              const c = await tryGeo().catch(() => null);
              if (c) {
                alert(`Location attached!\\nLatitude: ${c.latitude.toFixed(4)}\\nLongitude: ${c.longitude.toFixed(4)}`);
              } else {
                alert("Could not access your location. Please enable location permission.");
              }
            }}
          >
            📍 Use My Location
          </button>
        </div>
        
        {msg && <p className="success">✓ {msg}</p>}
      </form>
    </div>
  );
}
