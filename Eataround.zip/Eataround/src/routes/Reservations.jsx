import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { getUserReservations, cancelReservation, makeReservation, getRestaurantById } from "../lib/storage";

export default function Reservations({ user }) {
  const [reservations, setReservations] = useState([]);
  const [filter, setFilter] = useState("all"); // all, upcoming, completed, cancelled
  const [editingId, setEditingId] = useState(null);
  const [editData, setEditData] = useState({ date: "", time: "", guests: "2" });

  // Refresh reservations whenever component mounts or user changes
  useEffect(() => {
    if (user) {
      const userReservations = getUserReservations(user.id);
      setReservations(userReservations);
    }
  }, [user]);

  // Listen for changes in localStorage (for real-time updates)
  useEffect(() => {
    if (!user) return;

    const handleStorageChange = (e) => {
      if (e.key === "ea_reservations") {
        const userReservations = getUserReservations(user.id);
        setReservations(userReservations);
      }
    };

    // Also poll every 1 second to ensure we catch new reservations
    const interval = setInterval(() => {
      const userReservations = getUserReservations(user.id);
      setReservations(prevReservations => {
        // Only update if there are new reservations
        if (JSON.stringify(prevReservations) !== JSON.stringify(userReservations)) {
          return userReservations;
        }
        return prevReservations;
      });
    }, 1000);

    window.addEventListener("storage", handleStorageChange);
    return () => {
      window.removeEventListener("storage", handleStorageChange);
      clearInterval(interval);
    };
  }, [user]);

  if (!user) {
    return (
      <div className="container" style={{ textAlign: "center", padding: "60px 20px" }}>
        <h2 style={{ marginBottom: "16px" }}>Please log in to view reservations</h2>
        <Link to="/login" className="btn btn-primary">Sign In</Link>
      </div>
    );
  }

  function handleCancel(reservationId) {
    const ok = confirm("Are you sure you want to cancel this reservation?");
    if (!ok) return;
    const res = cancelReservation(reservationId, user.id);
    if (res) {
      setReservations(reservations.map(r => r.id === reservationId ? { ...r, status: "cancelled" } : r));
      alert("Reservation cancelled successfully");
    }
  }

  function startEdit(reservation) {
    setEditingId(reservation.id);
    setEditData({
      date: reservation.date,
      time: reservation.time,
      guests: reservation.guests.toString()
    });
  }

  function handleUpdateReservation(reservationId) {
    if (!editData.date || !editData.time || !editData.guests) {
      alert("Please fill in all fields");
      return;
    }

    // Update in the reservations list
    setReservations(reservations.map(r => 
      r.id === reservationId 
        ? { ...r, date: editData.date, time: editData.time, guests: Number(editData.guests) }
        : r
    ));

    setEditingId(null);
    alert("Reservation updated successfully");
  }

  function cancelEdit() {
    setEditingId(null);
    setEditData({ date: "", time: "", guests: "2" });
  }

  function getStatusColor(status) {
    switch (status) {
      case "confirmed":
        return "#2e7d32";
      case "cancelled":
        return "#c62828";
      case "completed":
        return "#1565c0";
      default:
        return "var(--text-secondary)";
    }
  }

  function getStatusLabel(status) {
    switch (status) {
      case "confirmed":
        return "✅ Confirmed";
      case "cancelled":
        return "❌ Cancelled";
      case "completed":
        return "✓ Completed";
      default:
        return status;
    }
  }

  const now = new Date();
  const filtered = reservations.filter(res => {
    const resDate = new Date(res.date);
    if (filter === "all") return true;
    if (filter === "upcoming") return res.status === "confirmed" && resDate >= now;
    if (filter === "completed") return resDate < now || res.status === "completed";
    if (filter === "cancelled") return res.status === "cancelled";
    return true;
  });

  return (
    <div className="container">
      <h1 style={{ marginBottom: "8px", fontSize: "2rem" }}>📅 My Reservations</h1>
      <p style={{ color: "var(--text-secondary)", marginBottom: "24px" }}>View and manage all your restaurant reservations</p>

      <div style={{ display: "flex", gap: "8px", marginBottom: "24px", flexWrap: "wrap" }}>
        <button 
          onClick={() => setFilter("all")}
          style={{
            padding: "8px 16px",
            background: filter === "all" ? "var(--accent)" : "white",
            color: filter === "all" ? "white" : "var(--text-primary)",
            border: filter === "all" ? "none" : "2px solid var(--border)",
            borderRadius: "6px",
            cursor: "pointer",
            fontWeight: "600",
            fontSize: "0.9rem"
          }}
        >
          All ({reservations.length})
        </button>
        <button 
          onClick={() => setFilter("upcoming")}
          style={{
            padding: "8px 16px",
            background: filter === "upcoming" ? "var(--accent)" : "white",
            color: filter === "upcoming" ? "white" : "var(--text-primary)",
            border: filter === "upcoming" ? "none" : "2px solid var(--border)",
            borderRadius: "6px",
            cursor: "pointer",
            fontWeight: "600",
            fontSize: "0.9rem"
          }}
        >
          Upcoming ({reservations.filter(r => r.status === "confirmed" && new Date(r.date) >= now).length})
        </button>
        <button 
          onClick={() => setFilter("completed")}
          style={{
            padding: "8px 16px",
            background: filter === "completed" ? "var(--accent)" : "white",
            color: filter === "completed" ? "white" : "var(--text-primary)",
            border: filter === "completed" ? "none" : "2px solid var(--border)",
            borderRadius: "6px",
            cursor: "pointer",
            fontWeight: "600",
            fontSize: "0.9rem"
          }}
        >
          Completed ({reservations.filter(r => new Date(r.date) < now || r.status === "completed").length})
        </button>
        <button 
          onClick={() => setFilter("cancelled")}
          style={{
            padding: "8px 16px",
            background: filter === "cancelled" ? "var(--accent)" : "white",
            color: filter === "cancelled" ? "white" : "var(--text-primary)",
            border: filter === "cancelled" ? "none" : "2px solid var(--border)",
            borderRadius: "6px",
            cursor: "pointer",
            fontWeight: "600",
            fontSize: "0.9rem"
          }}
        >
          Cancelled ({reservations.filter(r => r.status === "cancelled").length})
        </button>
      </div>

      {filtered.length > 0 ? (
        <div style={{ display: "grid", gap: "16px" }}>
          {filtered.map(res => (
            <div 
              key={res.id} 
              style={{ 
                background: "white", 
                padding: "20px", 
                borderRadius: "12px", 
                border: "2px solid var(--border)",
                borderLeft: `5px solid ${getStatusColor(res.status)}`
              }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start", marginBottom: "12px" }}>
                <div style={{ flex: 1 }}>
                  <Link to={`/r/${res.restaurantId}`} style={{ textDecoration: "none", color: "var(--accent)", fontWeight: "700", fontSize: "1.2rem" }}>
                    {res.restaurant?.name || "Restaurant"}
                  </Link>
                  <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem", margin: "4px 0" }}>
                    📍 {res.restaurant?.place || "Location not available"}
                  </p>
                </div>
                <span style={{ 
                  padding: "6px 12px", 
                  background: getStatusColor(res.status), 
                  color: "white", 
                  borderRadius: "6px", 
                  fontWeight: "600",
                  fontSize: "0.85rem",
                  whiteSpace: "nowrap"
                }}>
                  {getStatusLabel(res.status)}
                </span>
              </div>

              {editingId === res.id ? (
                <div style={{ background: "var(--bg)", padding: "20px", borderRadius: "8px", marginBottom: "16px" }}>
                  <h4 style={{ marginBottom: "16px", marginTop: "0" }}>Edit Reservation</h4>
                  
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: "12px", marginBottom: "16px" }}>
                    <div>
                      <label style={{ fontWeight: "600", display: "block", marginBottom: "6px", fontSize: "0.9rem" }}>📅 Date</label>
                      <input 
                        type="date"
                        value={editData.date}
                        onChange={(e) => setEditData({ ...editData, date: e.target.value })}
                        style={{ width: "100%", padding: "8px", borderRadius: "6px", border: "1px solid var(--border)" }}
                      />
                    </div>

                    <div>
                      <label style={{ fontWeight: "600", display: "block", marginBottom: "6px", fontSize: "0.9rem" }}>🕐 Time</label>
                      <input 
                        type="time"
                        value={editData.time}
                        onChange={(e) => setEditData({ ...editData, time: e.target.value })}
                        style={{ width: "100%", padding: "8px", borderRadius: "6px", border: "1px solid var(--border)" }}
                      />
                    </div>

                    <div>
                      <label style={{ fontWeight: "600", display: "block", marginBottom: "6px", fontSize: "0.9rem" }}>👥 Guests</label>
                      <select 
                        value={editData.guests}
                        onChange={(e) => setEditData({ ...editData, guests: e.target.value })}
                        style={{ width: "100%", padding: "8px", borderRadius: "6px", border: "1px solid var(--border)" }}
                      >
                        {[1, 2, 3, 4, 5, 6, 8, 10].map(n => <option key={n} value={n}>{n} guest{n !== 1 ? "s" : ""}</option>)}
                      </select>
                    </div>
                  </div>

                  <div style={{ display: "flex", gap: "8px" }}>
                    <button 
                      onClick={() => handleUpdateReservation(res.id)}
                      style={{ flex: 1, padding: "10px", background: "var(--accent)", color: "white", border: "none", borderRadius: "6px", cursor: "pointer", fontWeight: "600" }}
                    >
                      ✓ Save Changes
                    </button>
                    <button 
                      onClick={cancelEdit}
                      style={{ flex: 1, padding: "10px", background: "white", color: "var(--text-primary)", border: "2px solid var(--border)", borderRadius: "6px", cursor: "pointer", fontWeight: "600" }}
                    >
                      ✕ Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: "16px", marginBottom: "16px" }}>
                    <div>
                      <label style={{ fontWeight: "600", color: "var(--text-secondary)", fontSize: "0.85rem", display: "block", marginBottom: "4px" }}>📅 Date</label>
                      <p style={{ margin: "0", fontSize: "1rem", fontWeight: "600" }}>
                        {new Date(res.date).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", year: "numeric" })}
                      </p>
                    </div>
                    <div>
                      <label style={{ fontWeight: "600", color: "var(--text-secondary)", fontSize: "0.85rem", display: "block", marginBottom: "4px" }}>🕐 Time</label>
                      <p style={{ margin: "0", fontSize: "1rem", fontWeight: "600" }}>{res.time}</p>
                    </div>
                    <div>
                      <label style={{ fontWeight: "600", color: "var(--text-secondary)", fontSize: "0.85rem", display: "block", marginBottom: "4px" }}>👥 Guests</label>
                      <p style={{ margin: "0", fontSize: "1rem", fontWeight: "600" }}>{res.guests} guest{res.guests !== 1 ? "s" : ""}</p>
                    </div>
                  </div>

                  <div style={{ background: "var(--bg)", padding: "12px", borderRadius: "8px", marginBottom: "12px" }}>
                    <p style={{ margin: "0", color: "var(--text-secondary)", fontSize: "0.9rem" }}>
                      <strong>Name:</strong> {res.name} | <strong>Phone:</strong> {res.phone}
                    </p>
                  </div>

                  <div style={{ fontSize: "0.85rem", color: "var(--text-secondary)", marginBottom: "12px" }}>
                    Booked on {new Date(res.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" })}
                  </div>

                  {res.status === "confirmed" && new Date(res.date) >= new Date() && (
                    <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
                      <button 
                        onClick={() => startEdit(res)}
                        style={{
                          padding: "8px 16px",
                          background: "white",
                          color: "var(--accent)",
                          border: "2px solid var(--accent)",
                          borderRadius: "6px",
                          cursor: "pointer",
                          fontWeight: "600",
                          fontSize: "0.9rem"
                        }}
                      >
                        ✏️ Edit
                      </button>
                      <button 
                        onClick={() => handleCancel(res.id)}
                        style={{
                          padding: "8px 16px",
                          background: "white",
                          color: "var(--error)",
                          border: "2px solid var(--error)",
                          borderRadius: "6px",
                          cursor: "pointer",
                          fontWeight: "600",
                          fontSize: "0.9rem"
                        }}
                      >
                        🗑️ Cancel
                      </button>
                    </div>
                  )}
                </>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div style={{ textAlign: "center", padding: "60px 20px", background: "white", borderRadius: "12px" }}>
          <p style={{ color: "var(--text-secondary)", marginBottom: "16px", fontSize: "1rem" }}>
            {filter === "all" ? "No reservations yet!" : `No ${filter} reservations.`}
          </p>
          <Link to="/search" className="btn btn-primary">Explore Restaurants</Link>
        </div>
      )}
    </div>
  );
}
