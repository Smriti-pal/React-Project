import React from "react";
import { Link, useNavigate } from "react-router-dom";
import RestaurantCard from "../components/RestaurantCard";
import { getRestaurants } from "../lib/storage";

export default function Home() {
  const restaurants = getRestaurants();
  const [searchInput, setSearchInput] = React.useState("");
  const nav = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchInput.trim()) {
      // Navigate to search page with query parameter
      nav(`/search?q=${encodeURIComponent(searchInput)}`);
    }
  };

  return (
    <>
      {/* Hero Section */}
      <section className="hero" style={{ 
        backgroundImage: `url("https://images.unsplash.com/photo-1495521821757-a1efb6729352?w=1400&q=80")`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed",
        minHeight: "600px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
      }}>
        <div className="hero-inner" style={{ 
          background: "rgba(0, 0, 0, 0.5)",
          padding: "60px 20px",
          textAlign: "center",
          borderRadius: "16px",
          maxWidth: "700px"
        }}>
          <h1 style={{ fontSize: "3rem", marginBottom: "12px", fontWeight: "700", lineHeight: "1.2" }}>
            🍽️ Discover Hidden Food Gems
          </h1>
          <p style={{ fontSize: "1.1rem", marginBottom: "32px", opacity: "0.95" }}>
            Find authentic dishes and neighborhood favorites — suggested by locals and travelers worldwide.
          </p>

          <form onSubmit={handleSearch} className="search-bar" style={{ flexDirection: "column", gap: "12px" }}>
            <div style={{ display: "flex", gap: "8px", justifyContent: "center" }}>
              <input 
                type="text"
                placeholder="Search restaurants or dishes..."
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                style={{ flex: 1, maxWidth: "400px" }}
              />
              <button type="submit" className="btn btn-primary">🔍 Search</button>
            </div>
            <Link to="/nearby" style={{ width: "100%", maxWidth: "408px" }}>
              <button type="button" className="btn btn-ghost" style={{ width: "100%" }}>📍 Find Nearby Restaurants</button>
            </Link>
          </form>
        </div>
      </section>

      <div className="container">
        {/* Popular Picks Section */}
        <section style={{ marginTop: "60px", marginBottom: "60px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "32px" }}>
            <h2 style={{ fontSize: "2rem", fontWeight: "700", margin: "0" }}>⭐ Popular Picks</h2>
            <Link to="/search" style={{ color: "var(--accent)", fontWeight: "600", textDecoration: "none" }}>
              View All →
            </Link>
          </div>

          {restaurants.length > 0 ? (
            <div className="grid">
              {restaurants.slice(0, 12).map(r => <RestaurantCard key={r.id} r={r} />)}
            </div>
          ) : (
            <div style={{ textAlign: "center", padding: "60px 20px", background: "white", borderRadius: "12px", border: "1px solid var(--border)" }}>
              <p style={{ fontSize: "1.1rem", color: "var(--text-secondary)", marginBottom: "16px" }}>No restaurants available yet.</p>
              <Link to="/suggest" className="btn btn-primary">Suggest a Restaurant</Link>
            </div>
          )}
        </section>

        {/* CTA Section */}
        <section style={{ 
          background: "linear-gradient(135deg, var(--accent) 0%, #ff9800 100%)",
          padding: "60px 40px",
          borderRadius: "16px",
          textAlign: "center",
          marginBottom: "60px",
          color: "white"
        }}>
          <h2 style={{ fontSize: "2rem", marginBottom: "16px", fontWeight: "700" }}>Know a Great Restaurant?</h2>
          <p style={{ fontSize: "1.1rem", marginBottom: "24px", opacity: "0.95", maxWidth: "600px", margin: "0 auto 24px" }}>
            Help others discover amazing food experiences. Suggest a new restaurant and share your favorite dining spots with the community.
          </p>
          <Link to="/suggest">
            <button className="btn" style={{ background: "white", color: "var(--accent)", fontWeight: "700", padding: "12px 32px", fontSize: "1rem" }}>
              ➕ Suggest a Restaurant
            </button>
          </Link>
        </section>

        {/* About Us Section */}
        <section style={{ marginBottom: "60px" }}>
          <h2 style={{ textAlign: "center", marginBottom: "40px", fontSize: "2rem", fontWeight: "700" }}>About EatAround</h2>
          <p style={{ textAlign: "center", color: "var(--text-secondary)", marginBottom: "40px", fontSize: "1.1rem", maxWidth: "700px", margin: "0 auto 40px" }}>
            Discover what makes EatAround the perfect food companion for every dining occasion.
          </p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: "24px" }}>
            <div style={{ 
              padding: "24px", 
              borderRadius: "12px", 
              background: "white",
              border: "1px solid var(--border)",
              textAlign: "center",
              transition: "transform 0.3s, box-shadow 0.3s"
            }} 
            onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-8px)"; e.currentTarget.style.boxShadow = "0 12px 24px rgba(15,23,42,0.12)"; }}
            onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = ""; }}
            >
              <div style={{ fontSize: "3rem", marginBottom: "12px" }}>⭐</div>
              <h3 style={{ marginBottom: "8px", fontSize: "1.2rem" }}>Curated by Locals</h3>
              <p style={{ color: "var(--text-secondary)", lineHeight: "1.6" }}>Discover restaurants and dishes personally recommended by food lovers in your area.</p>
            </div>

            <div style={{ 
              padding: "24px", 
              borderRadius: "12px", 
              background: "white",
              border: "1px solid var(--border)",
              textAlign: "center",
              transition: "transform 0.3s, box-shadow 0.3s"
            }}
            onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-8px)"; e.currentTarget.style.boxShadow = "0 12px 24px rgba(15,23,42,0.12)"; }}
            onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = ""; }}
            >
              <div style={{ fontSize: "3rem", marginBottom: "12px" }}>📍</div>
              <h3 style={{ marginBottom: "8px", fontSize: "1.2rem" }}>Location Based</h3>
              <p style={{ color: "var(--text-secondary)", lineHeight: "1.6" }}>Find restaurants near you instantly. Browse by state, city, or neighborhood.</p>
            </div>

            <div style={{ 
              padding: "24px", 
              borderRadius: "12px", 
              background: "white",
              border: "1px solid var(--border)",
              textAlign: "center",
              transition: "transform 0.3s, box-shadow 0.3s"
            }}
            onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-8px)"; e.currentTarget.style.boxShadow = "0 12px 24px rgba(15,23,42,0.12)"; }}
            onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = ""; }}
            >
              <div style={{ fontSize: "3rem", marginBottom: "12px" }}>📅</div>
              <h3 style={{ marginBottom: "8px", fontSize: "1.2rem" }}>Easy Reservations</h3>
              <p style={{ color: "var(--text-secondary)", lineHeight: "1.6" }}>Book tables instantly, manage reservations, and get confirmation at your fingertips.</p>
            </div>

            <div style={{ 
              padding: "24px", 
              borderRadius: "12px", 
              background: "white",
              border: "1px solid var(--border)",
              textAlign: "center",
              transition: "transform 0.3s, box-shadow 0.3s"
            }}
            onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-8px)"; e.currentTarget.style.boxShadow = "0 12px 24px rgba(15,23,42,0.12)"; }}
            onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = ""; }}
            >
              <div style={{ fontSize: "3rem", marginBottom: "12px" }}>💬</div>
              <h3 style={{ marginBottom: "8px", fontSize: "1.2rem" }}>Share Reviews</h3>
              <p style={{ color: "var(--text-secondary)", lineHeight: "1.6" }}>Write honest reviews and read detailed feedback from real diners.</p>
            </div>

            <div style={{ 
              padding: "24px", 
              borderRadius: "12px", 
              background: "white",
              border: "1px solid var(--border)",
              textAlign: "center",
              transition: "transform 0.3s, box-shadow 0.3s"
            }}
            onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-8px)"; e.currentTarget.style.boxShadow = "0 12px 24px rgba(15,23,42,0.12)"; }}
            onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = ""; }}
            >
              <div style={{ fontSize: "3rem", marginBottom: "12px" }}>❤️</div>
              <h3 style={{ marginBottom: "8px", fontSize: "1.2rem" }}>Wishlist</h3>
              <p style={{ color: "var(--text-secondary)", lineHeight: "1.6" }}>Save your favorite restaurants and access them anytime from your profile.</p>
            </div>

            <div style={{ 
              padding: "24px", 
              borderRadius: "12px", 
              background: "white",
              border: "1px solid var(--border)",
              textAlign: "center",
              transition: "transform 0.3s, box-shadow 0.3s"
            }}
            onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-8px)"; e.currentTarget.style.boxShadow = "0 12px 24px rgba(15,23,42,0.12)"; }}
            onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = ""; }}
            >
              <div style={{ fontSize: "3rem", marginBottom: "12px" }}>🌍</div>
              <h3 style={{ marginBottom: "8px", fontSize: "1.2rem" }}>Community Driven</h3>
              <p style={{ color: "var(--text-secondary)", lineHeight: "1.6" }}>Part of a growing community of food enthusiasts sharing authentic dining experiences.</p>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}
