import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { checkEmailExists, resetPassword } from "../lib/storage";

export default function ForgotPassword() {
  const [step, setStep] = useState(1); // 1: email, 2: otp, 3: new password
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [generatedOtp, setGeneratedOtp] = useState("");
  const nav = useNavigate();

  function generateOTP() {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  }

  function handleEmailSubmit(e) {
    e.preventDefault();
    setError("");
    
    if (!email.trim()) {
      setError("Please enter your email");
      return;
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      setError("Please enter a valid email address");
      return;
    }
    
    if (!checkEmailExists(email.trim())) {
      setError("Email not found in our system");
      return;
    }
    
    const otp = generateOTP();
    setGeneratedOtp(otp);
    
    // Simulate sending email with OTP
    console.log(`📧 Email sent to ${email.trim()}`);
    console.log(`🔐 OTP Code: ${otp}`);
    
    // Show notification about sent email
    setSuccess(`✓ Verification code sent to ${email.trim()}! Check your email for the 6-digit code.`);
    
    setTimeout(() => {
      setSuccess("");
      setStep(2);
    }, 2000);
  }

  function handleOtpVerification(e) {
    e.preventDefault();
    setError("");
    
    if (!otp.trim()) {
      setError("Please enter the verification code");
      return;
    }
    
    if (otp.trim() !== generatedOtp) {
      setError("Verification code is incorrect. Please try again.");
      return;
    }
    
    setSuccess("✓ Email verified successfully!");
    setTimeout(() => {
      setSuccess("");
      setStep(3);
    }, 1500);
  }

  function handleResetPassword(e) {
    e.preventDefault();
    setError("");
    
    if (!newPassword || !confirmPassword) {
      setError("Please fill in all fields");
      return;
    }
    
    if (newPassword.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }
    
    if (newPassword !== confirmPassword) {
      setError("Passwords do not match. Please re-enter.");
      return;
    }
    
    const res = resetPassword(email, newPassword);
    if (res) {
      setSuccess("✓ Password reset successfully! Redirecting to login...");
      setTimeout(() => nav("/login"), 2000);
    } else {
      setError("Failed to reset password. Please try again.");
    }
  }

  return (
    <div className="container" style={{ maxWidth: "480px", margin: "40px auto" }}>
      <div className="card" style={{ padding: "40px", boxShadow: "0 10px 40px rgba(15,23,42,0.1)" }}>
        <div style={{ textAlign: "center", marginBottom: "32px" }}>
          <h1 style={{ color: "var(--accent)", marginBottom: "8px", fontSize: "2rem" }}>🔐 Reset Password</h1>
          <p style={{ color: "var(--text-secondary)", margin: "0" }}>Don't worry, we'll help you recover your account</p>
        </div>

        {/* Progress indicator */}
        <div style={{ display: "flex", gap: "8px", marginBottom: "32px", justifyContent: "center" }}>
          {[1, 2, 3].map((s) => (
            <div 
              key={s}
              style={{
                width: "40px",
                height: "40px",
                borderRadius: "50%",
                background: step >= s ? "var(--accent)" : "var(--border)",
                color: step >= s ? "white" : "var(--text-secondary)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontWeight: "600",
                fontSize: "0.9rem",
                transition: "all 0.3s ease"
              }}
            >
              {s === 1 ? "📧" : s === 2 ? "✓" : "🔑"}
            </div>
          ))}
        </div>

        {/* Step 1: Email */}
        {step === 1 && (
          <form onSubmit={handleEmailSubmit}>
            <div style={{ marginBottom: "24px" }}>
              <label htmlFor="email" style={{ fontWeight: "600", display: "block", marginBottom: "8px" }}>Email Address</label>
              <input 
                id="email"
                type="email"
                placeholder="Enter your registered email" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)}
                style={{ width: "100%", padding: "12px", borderRadius: "8px", border: "1px solid var(--border)" }}
                required 
              />
              <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", marginTop: "6px" }}>We'll send a verification code to this email</p>
            </div>
            
            {error && <div className="error" style={{ marginBottom: "16px" }}>⚠️ {error}</div>}
            {success && <div className="success" style={{ marginBottom: "16px" }}>✓ {success}</div>}
            
            <button type="submit" className="btn btn-primary" style={{ marginTop: "16px", width: "100%", padding: "12px" }}>
              Send Verification Code
            </button>
          </form>
        )}

        {/* Step 2: OTP Verification */}
        {step === 2 && (
          <form onSubmit={handleOtpVerification}>
            <div style={{ background: "#e8f5e9", padding: "16px", borderRadius: "8px", marginBottom: "24px", border: "1px solid #4caf50" }}>
              <p style={{ color: "#2e7d32", margin: "0", fontSize: "0.95rem" }}>
                ✓ <strong>Email verified:</strong> {email}
              </p>
            </div>

            {/* Demo OTP Display */}
            <div style={{ background: "#fff3cd", padding: "16px", borderRadius: "8px", marginBottom: "24px", border: "1px solid #ffc107" }}>
              <p style={{ color: "#856404", margin: "0 0 8px 0", fontSize: "0.9rem", fontWeight: "600" }}>📧 Demo: Your verification code is:</p>
              <p style={{ color: "#856404", margin: "0", fontSize: "1.3rem", fontWeight: "700", letterSpacing: "2px", fontFamily: "monospace" }}>
                {generatedOtp}
              </p>
              <p style={{ color: "#856404", margin: "8px 0 0 0", fontSize: "0.85rem" }}>In a real app, this would be sent to your email</p>
            </div>

            <div style={{ marginBottom: "24px" }}>
              <label htmlFor="otp" style={{ fontWeight: "600", display: "block", marginBottom: "8px" }}>Verification Code</label>
              <p style={{ fontSize: "0.9rem", color: "var(--text-secondary)", marginBottom: "12px" }}>Enter the 6-digit code sent to your email</p>
              <input 
                id="otp"
                type="text"
                placeholder="e.g., ABC123" 
                value={otp} 
                onChange={(e) => setOtp(e.target.value.toUpperCase())}
                maxLength="6"
                style={{ width: "100%", padding: "12px", borderRadius: "8px", border: "1px solid var(--border)", fontSize: "1.1rem", letterSpacing: "2px", textAlign: "center", fontWeight: "600" }}
                required 
              />
            </div>
            
            {error && <div className="error" style={{ marginBottom: "16px" }}>⚠️ {error}</div>}
            {success && <div className="success" style={{ marginBottom: "16px" }}>✓ {success}</div>}
            
            <button type="submit" className="btn btn-primary" style={{ marginTop: "16px", width: "100%", padding: "12px" }}>
              Verify Code
            </button>

            <button 
              type="button"
              onClick={() => { setStep(1); setError(""); setSuccess(""); setOtp(""); }}
              style={{ marginTop: "12px", width: "100%", padding: "12px", background: "white", color: "var(--accent)", border: "2px solid var(--accent)", borderRadius: "8px", cursor: "pointer", fontWeight: "600" }}
            >
              ← Back to Email
            </button>
          </form>
        )}

        {/* Step 3: New Password */}
        {step === 3 && (
          <form onSubmit={handleResetPassword}>
            <div style={{ background: "#e3f2fd", padding: "16px", borderRadius: "8px", marginBottom: "24px", border: "1px solid #2196f3" }}>
              <p style={{ color: "#1565c0", margin: "0", fontSize: "0.95rem" }}>
                ✓ <strong>Verified:</strong> Create your new password
              </p>
            </div>

            <div style={{ marginBottom: "20px" }}>
              <label htmlFor="new-pwd" style={{ fontWeight: "600", display: "block", marginBottom: "8px" }}>New Password</label>
              <input 
                id="new-pwd"
                type="password" 
                placeholder="Create a strong password (min 6 characters)"
                value={newPassword} 
                onChange={(e) => setNewPassword(e.target.value)}
                style={{ width: "100%", padding: "12px", borderRadius: "8px", border: "1px solid var(--border)" }}
                required 
              />
              <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", marginTop: "6px" }}>Use uppercase, lowercase, and numbers for a strong password</p>
            </div>

            <div style={{ marginBottom: "24px" }}>
              <label htmlFor="confirm-pwd" style={{ fontWeight: "600", display: "block", marginBottom: "8px" }}>Confirm Password</label>
              <input 
                id="confirm-pwd"
                type="password" 
                placeholder="Re-enter your password"
                value={confirmPassword} 
                onChange={(e) => setConfirmPassword(e.target.value)}
                style={{ width: "100%", padding: "12px", borderRadius: "8px", border: "1px solid var(--border)" }}
                required 
              />
            </div>
            
            {error && <div className="error" style={{ marginBottom: "16px" }}>⚠️ {error}</div>}
            {success && <div className="success" style={{ marginBottom: "16px" }}>✓ {success}</div>}
            
            <button type="submit" className="btn btn-primary" style={{ marginTop: "16px", width: "100%", padding: "12px" }}>
              Reset Password
            </button>

            <button 
              type="button"
              onClick={() => { setStep(2); setError(""); setSuccess(""); setNewPassword(""); setConfirmPassword(""); }}
              style={{ marginTop: "12px", width: "100%", padding: "12px", background: "white", color: "var(--accent)", border: "2px solid var(--accent)", borderRadius: "8px", cursor: "pointer", fontWeight: "600" }}
            >
              ← Back to Verification
            </button>
          </form>
        )}

        <div style={{ marginTop: "24px", textAlign: "center", fontSize: "0.95rem", paddingTop: "24px", borderTop: "1px solid var(--border)" }}>
          Remember your password? <Link to="/login" style={{ color: "var(--accent)", fontWeight: "600", textDecoration: "none" }}>Back to Login</Link>
        </div>
      </div>
    </div>
  );
}
